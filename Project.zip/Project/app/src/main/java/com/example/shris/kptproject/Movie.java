package com.example.shris.kptproject;

/*
 * Created by Heena on 3/24/2018.
 */
public class Movie implements Comparable<Movie> {
    private int movie_index;
    private String title;
    private double assigned_rating;

    @Override
    public int compareTo(Movie o) {
        if (this.assigned_rating == o.assigned_rating) return  0;
        return this.assigned_rating > o.assigned_rating ? 1:-1;
    }

    public void setMovie_index(int movie_index) {
        this.movie_index = movie_index;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAssigned_rating(double assigned_rating) {
        this.assigned_rating = assigned_rating;
    }

    public int getMovie_index() {
        return movie_index;
    }

    public double getAssigned_rating() {
        return assigned_rating;
    }
}
