package com.example.shris.kptproject;
/*
 * Created by Shristika on 4/07/2018.
 */
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.*;
import java.io.*;
import java.lang.reflect.Array;
import java.util.*;

public class rateMovie extends AppCompatActivity {
    static HashMap<Integer,String> hmap;
    TextView movieName;
    EditText setRating;
    Button getRating;
    ArrayList<Integer> moviesRatedByUser;
    ArrayList<Double> ratingGivenByUser;
    InputStream ratings_file_name;
    InputStream movie_file_name;
    ArrayList<Integer> newMovieId;
    ArrayList<ArrayList<Double>> userMatrix;
    ArrayList<Integer> movieIDList;             // movie ids from movies_metadata.csv for easy access
    ArrayList<String> movieNameList;          // movie name from movies_metadata.csv for easy access
    ArrayList<String> recommendedMovies;        // movies recommended for user
    ArrayList<String> recommendedMovieImdbLink;     // movies imdb link.
    ArrayList<String> movieImdbId;              // store imdb IDs.
    ArrayList<ArrayList<String>> movieGenreList;

    int userId;
    String userGenre;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate_movie);
        movieName = (TextView) findViewById(R.id.movieName);
        setRating = (EditText) findViewById(R.id.rating);
        getRating = (Button) findViewById(R.id.submitRating);
        moviesRatedByUser = new ArrayList<Integer>();
        ratingGivenByUser = new ArrayList<Double>();
        ratings_file_name = getResources().openRawResource(R.raw.ratings);
        movie_file_name = getResources().openRawResource(R.raw.movies_metadata);
        hmap = new HashMap<Integer, String>();
        newMovieId = new ArrayList<Integer>();
        userMatrix = new ArrayList<ArrayList<Double>>();
        movieGenreList = new ArrayList<ArrayList<String>>();
        movieIDList = new ArrayList<Integer>();
        movieNameList = new ArrayList<String>();
        recommendedMovies = new ArrayList<String>();
        movieImdbId = new ArrayList<String>();
        recommendedMovieImdbLink = new ArrayList<String>();
        userGenre = "";


        Intent i= getIntent();

//      Getting data from the selectGenre file.
        moviesRatedByUser = i.getIntegerArrayListExtra("movieList");
        ratingGivenByUser = (ArrayList<Double>) i.getSerializableExtra("ratingList");
        userId = i.getIntExtra("userId",0);
        userGenre = i.getStringExtra("userGenre");

//        Calling all the functions
        createMetadata();
        createUserMovieRatingsMatrix(userId,moviesRatedByUser,ratingGivenByUser.toArray());
        getRecommendedMoviesForUser(userId);
        showRecommendedMovie();
    }


    /**
     * Reads meta data file and store the movie id, movie title and movie Imdb id in three different arraysList for easy access.
     * Will be used in methods getTitleFromId() and getImdbFromId().
     */
    public void createMetadata(){
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(movie_file_name));
            String line;
            ArrayList<String> newGenreList;
            while ((line = br.readLine()) != null) {
                newGenreList = new ArrayList<String>();
                String[] cols = line.split(",");
                if(cols[0].equals("id")) continue;
                Integer movieId = Integer.valueOf(cols[0]);
                movieIDList.add(movieId);
                movieImdbId.add(cols[1]);
                movieNameList.add(cols[2]);
                for(int c=4;c<cols.length;c+=2){
                    String [] genre_breakdown = cols[c].split(":");
                    if(genre_breakdown.length > 1)
                    {
                        newGenreList.add(genre_breakdown[1].replaceAll("[^\\w]",""));
                    }
                }
                movieGenreList.add(newGenreList);
            }

        }catch (IOException|NumberFormatException ex){
            Log.i("WARNING MESSAGE",ex.getMessage());
        }

    }


    /**
     * Sends the recommended movies and its related Imdb ids to recommendedMovies.class to be displayed on the screen.
     */
    public void showRecommendedMovie(){
//        Log.d("check","sendData");
        Intent i = new Intent(this,recommendedMovies.class);
        i.putExtra("moviesRecom",recommendedMovies);
        i.putExtra("imdbRecom",recommendedMovieImdbLink);
        startActivity(i);
    }

    /**
     * Creates a User and Movie id matrix using ArrayList<ArraysList>
     * @param newUser = ID of new User
     * @param movieId = ID's of all the movies rated by user
     * @param MovieRate = Movie rating of all the movies rated by user.
     */
    public void createUserMovieRatingsMatrix(int newUser, ArrayList<Integer>  movieId, Object[] MovieRate){
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(ratings_file_name));


            newMovieId.add(0);
            ArrayList<Integer> tempMovieId = new ArrayList<Integer>();
            ArrayList<Double> tempMovieRate = new ArrayList<Double>();


            String line;
            Integer userId = 0;
            int currentSize = 0;
            boolean contains = false;

//          Reading the file line by line.
            while ((line = br.readLine()) != null) {
                String[] cols = line.split(",");
                if(cols[1].equals("movieId")) continue;

//               If we have the data for the user has rated even one of the movie rated by our new user, movie ID gets added.
                if(!Integer.valueOf(cols[0]).equals(userId)){
                    if(contains == true){
                        ArrayList<Double> ar = new ArrayList<Double>();
                        ar.add(new Double(userId));
                        if (newMovieId.size()>0){
                            currentSize = newMovieId.size();
                            while(currentSize-1>0){
                                ar.add((double) 0);
                                currentSize--;
                            }
                        }
                        for(int idx=0;idx<tempMovieId.size();idx++){
                            if(newMovieId.contains(tempMovieId.get(idx))){
                                int index = newMovieId.indexOf(tempMovieId.get(idx));
                                ar.set(index, tempMovieRate.get(idx));
                            }else{
                                newMovieId.add(tempMovieId.get(idx));
                                ar.add(tempMovieRate.get(idx));
                            }
                        }
                        userMatrix.add(ar);
                    }
                    userId = Integer.valueOf(cols[0]);
                    tempMovieId = new ArrayList<Integer>();
                    tempMovieRate = new ArrayList<Double>();
                    contains = false;
                }

                if(movieId.contains(Integer.valueOf(cols[1]))){
                    contains = true;
                }
                tempMovieId.add(Integer.valueOf(cols[1]));
                tempMovieRate.add(Double.valueOf(cols[2]));

            }

//          Adding new user to the matrix created.
            ArrayList<Double> ar = new ArrayList<Double>();
            ar.add(new Double(newUser));
            if (newMovieId.size()>0){
                currentSize = newMovieId.size();
                while(currentSize-1>0){
                    ar.add((double) 0);
                    currentSize--;
                }
            }
            for(int idx=0;idx<movieId.size();idx++){
                int index = newMovieId.indexOf(movieId.get(idx));
                ar.set(index, (Double) MovieRate[idx]);
            }
            userMatrix.add(ar);

            for(ArrayList<Double> l1 : userMatrix){
                while(l1.size()!=newMovieId.size()){
                    l1.add((double) 0);
                }
            }
        } catch (IOException ex) {
            Log.i("WARNING MESSAGE",ex.getMessage());
        }
    }


    /**
     * Creates an item-to-item(movie-to-movie) similarity matrix from the user-movie ratings data table
     * Consists of pairwise cosine similarity calculation over every pair of movies
     * @return similarity matrix
     */
    public Double[][] createSimilarityMatrix(){

        Double[][] similarMatrix = new Double[newMovieId.size()][newMovieId.size()];
        double[] movie1;
        double[] movie2;
        for(int idx = 1;idx<similarMatrix.length;idx++){
            for(int jdx = idx;jdx<similarMatrix[0].length;jdx++){
                if(idx!=jdx){
                    movie1 = new double[userMatrix.size()];
                    movie2 = new double[userMatrix.size()];

//					create two movie lists to find cosine similarity between them
                    int count = 0;
                    for (ArrayList<Double> l1 : userMatrix) {
                        movie1[count] = l1.get(idx);
                        movie2[count++] = l1.get(jdx);
                    }

                    similarMatrix[idx][jdx] = getSimilarity(movie1, movie2);
                    similarMatrix[jdx][idx] = similarMatrix[idx][jdx];
                }else{
                    similarMatrix[idx][jdx] = (double) 1;
                }
            }
        }
        return similarMatrix;
    }


    /**
     * Calculates the cosine similarity between 2 vectors representing ratings by all users for 2 movies
     * @param movieA Vector of ratings corresponding to the first movie
     * @param movieB Vector of ratings corresponding to the second movie
     * @return The normalized similarity score - cosine similarity in the range [0,1]
     */
    public static double getSimilarity(double[] movieA, double[] movieB) {
        double dotProduct = 0.0;
        double norm_movieA = 0.0;
        double norm_movieB = 0.0;
        for (int i = 0; i < movieA.length; i++) {
            dotProduct += movieA[i] * movieB[i];
            norm_movieA += Math.pow(movieA[i], 2);
            norm_movieB += Math.pow(movieB[i], 2);
        }
        return dotProduct / (Math.sqrt(norm_movieA) * Math.sqrt(norm_movieB));
    }


    /**
     * Returns a list of recommended movies for the user with userId user+1
     * @param userId = userId of the user for whom we need to recommend movies
     */

    public void getRecommendedMoviesForUser(int userId){
//        Log.d("check","getRecom");
        Double[][] similarity_score_matrix = createSimilarityMatrix();
        Object[] num = null;
        double numerator = 0.0;
        double weighing_factor = 0.0;
        Movie m;
        HashMap<Integer,Double> hm = new HashMap<Integer,Double>();
        PriorityQueue < Movie >  probable_ratings = new PriorityQueue<Movie>(1000, Collections.reverseOrder()) ;

        for (ArrayList<Double> l1 : userMatrix) {
            if(l1.get(0).intValue() == userId){
                num = l1.toArray();
                for(int idx = 1;idx<num.length;idx++){
                    if((double)num[idx]>0){
                        hm.put(newMovieId.get(idx), new Double((double) num[idx]));
                    }
                }
                break;
            }
        }

//      CALCULATING SIMILARITY SCORE.
        for(int idx = 1;idx<newMovieId.size();idx++){
            if(!hm.containsKey(newMovieId.get(idx))){
                for(int j = 1;j<newMovieId.size();j++){
                    if(hm.containsKey(newMovieId.get(j))){
                        numerator += (hm.get(newMovieId.get(j)) * similarity_score_matrix[idx][j]);

                        if(hm.containsKey(newMovieId.get(j)) == true){
                            weighing_factor += similarity_score_matrix[idx][j];
                        }
//                        weighing_factor += similarity_score_matrix[idx][j];
                    }
                }
                m = new Movie();
                m.setMovie_index(newMovieId.get(idx));
                m.setAssigned_rating(numerator/weighing_factor);
                probable_ratings.add(m);

                numerator = 0.0;
                weighing_factor = 0.0;
            }
        }


//		GET TOP MOVIES
        int count = 0;
        for (Movie element : probable_ratings) {
            if (count == 5)
                break;
            else if(getGenresFromId(element.getMovie_index())){
                recommendedMovies.add(getTitleFromId(element.getMovie_index()));
                recommendedMovieImdbLink.add(getImdbFromId(element.getMovie_index()));
                count++;
            }
        }
    }


    /**
     * Depending upon the index of movie, it gets the name of the movie from an arraylist called movieNameList
     * @param movie_id = movie Id of the movie whose name we need to find
     * @return the name of the movie
     */
    public String getTitleFromId(int movie_id){
        if(movieIDList.contains(movie_id)){
            return movieNameList.get(movieIDList.indexOf(movie_id));
        }
        return "";
    }

    /**
     * Depending upon the index of movie, it gets the IMDB id of the movie from an arraylist called movieIMDBId
     * @param movie_id = movie Id of the movie whose name we need to find
     * @return the imdb id of the movie
     */
    public String getImdbFromId(int movie_id){
        if(movieIDList.contains(movie_id)){
            return movieImdbId.get(movieIDList.indexOf(movie_id));
        }
        return "";
    }

    public boolean getGenresFromId(int movie_id){
        ArrayList<String> genreList = new ArrayList<String>();
        if(movieIDList.contains(movie_id)){
            genreList = movieGenreList.get(movieIDList.indexOf(movie_id));
            if (genreList.contains(userGenre))
                return true;

        }
        return false;
    }
}