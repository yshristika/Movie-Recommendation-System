package com.example.shris.kptproject;
/*
 * Created by Shristika on 4/08/2018.
 */
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class recommendedMovies extends AppCompatActivity {
    ListView recommendedMovieListView;
    ArrayList<String> recommendedMoviesImdbLink;
    String selectedMovie="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recommend_movie);
        recommendedMovieListView = (ListView) findViewById(R.id.movieRecommend);

        Intent i= getIntent();
        final ArrayList<String> recommendedMovies = i.getStringArrayListExtra("moviesRecom");
        recommendedMoviesImdbLink = i.getStringArrayListExtra("imdbRecom");

//        Shows the recommended movies for the user in the list view format
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,recommendedMovies);
        recommendedMovieListView.setAdapter(arrayAdapter);


//      On clicking the movie, will direct to the imdb page.
        recommendedMovieListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                selectedMovie = (String) recommendedMovieListView.getItemAtPosition(i);
                Intent myIntent = new Intent(getApplicationContext(),webActivity.class);
                myIntent.putExtra("imdbRecom",recommendedMoviesImdbLink.get(recommendedMovies.indexOf(selectedMovie)));
                startActivity(myIntent);
            }
        });
    }
}
