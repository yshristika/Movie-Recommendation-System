package com.example.shris.kptproject;
/*
 * Created by Shristika on 4/10/2018.
 */
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.ArrayList;

public class webActivity extends AppCompatActivity {
    String recommendedMoviesImdbLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web);

        Intent i= getIntent();
        recommendedMoviesImdbLink =i.getStringExtra("imdbRecom");
        String url = "http://www.imdb.com/title/"+recommendedMoviesImdbLink;
        WebView web = (WebView) findViewById(R.id.imdbPage);

        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setLoadWithOverviewMode(true);
        web.getSettings().setUseWideViewPort(true);
        web.setWebViewClient(new ourViewClient());
        web.loadUrl(url);

    }
}
