package com.example.shris.kptproject;
/*
 * Created by Shristika on 4/07/2018.
 */
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.*;
import java.io.*;


public class SelectGenre extends AppCompatActivity {
    ArrayList<String> movieList;
    ArrayList<Integer> movieIdList;
    ListView genreListView;
    ArrayAdapter<String> arrayAdapter;
    String chosenGenre = "";
    Button showRecommend;
    String selectedMovie = "";
    ArrayList<Double> ratingGivenByUser;
    ArrayList<Integer> moviesRatedByUser;
    int userId = 673;
    TextView header;
    TextView middleLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);

        try{
            Thread.sleep(2000);
        }catch (InterruptedException e) {
            e.printStackTrace();
        }
        setContentView(R.layout.activity_select_genre);
        middleLink = (TextView) findViewById(R.id.middleLink);
        header = (TextView) findViewById(R.id.header);
        movieList = new ArrayList<String>();
        movieIdList = new ArrayList<Integer>();
        genreListView = (ListView) findViewById(R.id.genreListView);
        ratingGivenByUser = new ArrayList<Double>();
        moviesRatedByUser = new ArrayList<Integer>();
        showRecommend = (Button) findViewById(R.id.showRecommend);
        showRecommend.setVisibility(View.INVISIBLE);
        middleLink.setVisibility(View.INVISIBLE);

        String[] genreType  = initializeArrayList();
        arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,genreType);
        genreListView.setAdapter(arrayAdapter);

        genreListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                chosenGenre = (String) genreListView.getItemAtPosition(i);
                getGenresFromId();
                showNewList();
            }
        });


    }


    /**
     *SHOW MOVIE LIST OF A PARTICULAR GENRE AND GET RATINGS IN ON THE SCREEN.
     */
    public void showNewList(){
        header.setText("Rate Movie");
        middleLink.setVisibility(View.VISIBLE);
        showRecommend.setVisibility(View.VISIBLE);
        genreListView.setAdapter(null);
        arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,movieList);
        genreListView.setAdapter(arrayAdapter);
        genreListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                final AlertDialog.Builder mBuilder = new AlertDialog.Builder(SelectGenre.this);
                final View mView = getLayoutInflater().inflate(R.layout.activity_rate_movie,null);
                selectedMovie = (String) genreListView.getItemAtPosition(i);
                final TextView movieName = (TextView) mView.findViewById(R.id.movieName);
                final EditText setRating = (EditText) mView.findViewById(R.id.rating);
                final Button getRating = (Button) mView.findViewById(R.id.submitRating);



                movieName.setText(selectedMovie);
                mBuilder.setView(mView);

//                SHOWS POPUP WINDOW TO GET THE RATING OF A PARTICULAR MOVIE.
                final AlertDialog dialog = mBuilder.create();
                dialog.show();


//              GET VALUES IN FROM THE POP UP.
                    getRating.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            moviesRatedByUser.add(movieIdList.get(movieList.indexOf(selectedMovie)));
                            ratingGivenByUser.add(Double.parseDouble(setRating.getText().toString()));
                            dialog.cancel();
                        }
                    });
            }
        });

//        SENDING DATA TO RATEMOVIE TO FIND THE MOVIES WHICH CAN BE RECOMMENDED.
        showRecommend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(getApplicationContext(),rateMovie.class);
                myIntent.putExtra("movieList",moviesRatedByUser);
                myIntent.putExtra("ratingList",ratingGivenByUser);
                myIntent.putExtra("userId",userId);
                myIntent.putExtra("userGenre",chosenGenre);
                startActivity(myIntent);
            }
        });
    }

    /**
     * Initialize the arraylist with the name of the genre.
     * @return
     */
    public String[] initializeArrayList(){

        String[] genre_list = {"Animation", "Comedy", "Family", "Adventure", "Fantasy",
                "Romance", "Drama", "Action", "Crime", "Thriller", "Horror", "History", "ScienceFiction", "Mystery", "War", "Foreign",
                "Music", "Documentary", "Western", "TVMovie"};
        Arrays.sort(genre_list);
        return genre_list;
    }

    /**
     * CREATE THE MOVIE LIST FOR A PARTICULAR GENRE AFTER GETTING THE GENRE FROM THE USER.
     */
    public void getGenresFromId(){
        int count = 0;
        InputStream inputStream = getResources().openRawResource(R.raw.movies_metadata);
        try{
            BufferedReader br = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = br.readLine()) != null) {
                String[] cols = line.split(",");
                if(cols[0].equals("id")) continue;
                for(int c=4;c<cols.length;c+=2){
                    String [] genre_breakdown = cols[c].split(":");
                    if(genre_breakdown.length>1 && genre_breakdown[0].split("'").length>1 && genre_breakdown[0].split("'")[1].equals("name") && chosenGenre.equals(genre_breakdown[1].replaceAll("[^\\w]",""))){
                        movieList.add(cols[2]);
                        count++;
                        movieIdList.add(Integer.parseInt(cols[0]));
                    }
                }
                if(count == 5)
                    break;
            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}