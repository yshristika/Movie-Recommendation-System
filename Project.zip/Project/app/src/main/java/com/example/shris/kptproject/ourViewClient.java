package com.example.shris.kptproject;

/*
 * Created by Shris on 4/10/18.
 */

import android.webkit.WebView;
import android.webkit.WebViewClient;


public class ourViewClient extends WebViewClient{
    @Override
    public boolean shouldOverrideUrlLoading(WebView v, String url)
    {
        v.loadUrl(url);
        return true;
    }
}
